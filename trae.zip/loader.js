"use strict";

/**
 * js-confuser 加载器
 *
 * 原始文件是 browserify 打包的 standalone bundle，在浏览器环境下运行。
 * 该 bundle 在末尾直接引用 `window.obfuscate = obfuscate`，
 * 而 Node.js 中不存在 `window` 全局变量，会导致 ReferenceError。
 *
 * 本加载器通过注入 `window` shim 来安全加载该 bundle，
 * 之后从 `global.JsConfuser` 获取混淆函数。
 */

const path = require("path");

// ── window shim ──────────────────────────────────────────────
// bundle 中有两处引用 window：
//   1) if (typeof window !== "undefined") { window["JsConfuser"] = ... }
//   2) window.obfuscate = obfuscate;   ← 这一行无条件执行
// 用一个空对象做 shim 即可，真正的导出走 global["JsConfuser"]。
if (typeof global.window === "undefined") {
  global.window = {};
}

// 执行 bundle（browserify standalone 格式，自执行 IIFE）
require(path.join(__dirname, "js-confuser.bundle.js"));

// bundle 执行后在 global 上挂载 JsConfuser
const JsConfuser = global.JsConfuser;

if (!JsConfuser || typeof JsConfuser.obfuscate !== "function") {
  throw new Error("Failed to load js-confuser: obfuscate function not found on global.JsConfuser");
}

module.exports = JsConfuser;
module.exports.obfuscate = JsConfuser.obfuscate;
